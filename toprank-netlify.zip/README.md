# Top Rank MagangHub Bapas Kelas II Ciangir (versi Netlify)

Semua orang bisa MELIHAT peringkat. Hanya yang tahu kata sandi pengelola yang bisa MENGISI absensi.

## Cara pasang (gratis)

Catatan: cara "drag and drop" Netlify TIDAK memasang fungsi server, jadi pakai GitHub.

1. Buat akun di github.com (gratis), lalu klik New repository, beri nama bebas, misalnya `toprank-ciangir`.
2. Klik "uploading an existing file", lalu unggah SEMUA isi folder ini (folder `public`, folder `netlify`, `package.json`, `netlify.toml`). Klik Commit changes.
3. Buka app.netlify.com, daftar atau masuk (bisa pakai akun GitHub).
4. Add new site > Import an existing project > GitHub > pilih repository tadi > Deploy. Biarkan pengaturan build apa adanya (sudah diatur di netlify.toml).
5. Buka Site configuration > Environment variables > Add a variable:
   - Key: `ADMIN_PASSWORD`
   - Value: kata sandi pilihanmu (jangan dibagikan)
6. Buka Deploys > Trigger deploy > Deploy site, supaya kata sandi terbaca.
7. Buka alamat situsmu (xxxx.netlify.app). Klik "Masuk pengelola" di bagian bawah halaman, masukkan kata sandi, lalu isi absensi.

## Catatan
- Data disimpan di Netlify Blobs (bagian dari akun Netlify-mu), bukan di browser.
- Untuk mengganti kata sandi: ubah ADMIN_PASSWORD, lalu deploy ulang.
- Untuk mengganti nama peserta: ubah daftar NAMES di `public/index.html` DAN di `netlify/functions/absensi.mjs`.
- Jangan pakai Deploy Preview untuk mengisi data, karena data di Netlify Blobs dipakai bersama semua deploy.
